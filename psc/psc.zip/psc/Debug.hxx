/*
**
** Interface file for module
**
**
**
** exa
**
*/

#ifndef Debug_Interface
#define Debug_Interface 1

#include "General.hxx"

void check_point();

#endif









