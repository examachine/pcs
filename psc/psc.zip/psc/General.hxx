/*
**
** General Interface file
**
** Common system interfaces
**
** exa
**
*/

#ifndef General_Interface
#define General_Interface 1

#include <typeinfo>
#include <stl.h>
#include <string>
#include <stdexcept>
#include <iostream>
#include <fstream>
#include <cstdlib>

//#include "Set.hxx"

#endif



