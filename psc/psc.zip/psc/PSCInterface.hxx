/*
**
** Interface file for module
**
**
**
** exa
**
*/

#ifndef _Interface
#define _Interface 1

#include "General.hxx"

#include "Scanner.hxx"
#include "CFG.hxx"
#include "PascalSubset.hxx"
#include "Debug.hxx"


#endif









